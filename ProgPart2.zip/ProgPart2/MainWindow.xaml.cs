﻿using CybersecurityChatBot;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ProgPart2
{
    public partial class MainWindow : Window
    {
        private readonly ChatbotEngine chatbotEngine;
        private readonly AudioPlayer audioPlayer;
        private readonly AsciiArtGenerator asciiArt;
        private MessageHelper messageHelper;   // Not readonly

        public MainWindow()
        {
            InitializeComponent();
            chatbotEngine = new ChatbotEngine();
            audioPlayer = new AudioPlayer();
            asciiArt = new AsciiArtGenerator();
            Loaded += MainWindow_Loaded;
        }

        private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Create MessageHelper AFTER XAML controls are loaded
            messageHelper = new MessageHelper(ChatPanel, ChatScrollViewer);

            ShowAsciiLogo();
            await Task.Delay(800);

            _ = Task.Run(() =>
            {
                try { audioPlayer.PlayGreeting(); } catch { }
            });

            await Task.Delay(500);
            string username = GetUserName();
            chatbotEngine.SetUserName(username);

            ShowWelcomeAscii(username);
            await Task.Delay(500);

            messageHelper.AddBotMessage($"Hello {username}! I'm your Cybersecurity Awareness Bot 🛡️", Colors.Cyan);
            messageHelper.AddBotMessage("Ask me about passwords, phishing, malware, ransomware, VPN, firewall, etc.", Colors.White);

            InputTextBox.Focus();
        }

        private void ShowAsciiLogo()
        {
            string logo = @"CYBER SECURITY BOT LOADING...";
            ChatPanel.Children.Add(new TextBlock
            {
                Text = logo,
                FontFamily = new FontFamily("Consolas"),
                Foreground = Brushes.Cyan,
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Center
            });
        }

        private void ShowWelcomeAscii(string username)
        {
            string ascii = asciiArt.GetWelcomeAsciiText("WELCOME", username);
            ChatPanel.Children.Add(new TextBlock
            {
                Text = ascii,
                FontFamily = new FontFamily("Consolas"),
                FontSize = 11,
                Foreground = Brushes.Cyan,
                TextAlignment = TextAlignment.Center
            });
        }

        private string GetUserName()
        {
            var input = Microsoft.VisualBasic.Interaction.InputBox(
                "Enter your name:", "Welcome", "Friend");
            return string.IsNullOrWhiteSpace(input) ? "Friend" : input.Trim();
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            SendMessage();
        }

        private void InputTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                SendMessage();
        }

        private void SendMessage()
        {
            string input = InputTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(input)) return;

            try
            {
                messageHelper.AddUserMessage(input);
                string response = chatbotEngine.GetResponse(input);
                messageHelper.AddBotMessage(response);
                InputTextBox.Clear();
                ChatScrollViewer.ScrollToEnd();
            }
            catch (Exception ex)
            {
                messageHelper?.AddBotMessage($"[ERROR] {ex.Message}", Colors.Red);
            }
        }
    }
}