﻿using System;
using System.Collections.Generic;

namespace ProgPart2
{
    public class ChatbotEngine
    {
        private readonly Random rand = new Random();
        private string userName = "Friend";
        private string favoriteTopic = "";

        private readonly Dictionary<string, string[]> responses;

        public ChatbotEngine()
        {
            responses = new Dictionary<string, string[]>
            {
                // Previous keywords
                { "password", new[]
                    {
                        "Use strong, unique passwords with at least 12 characters. Mix letters, numbers, and symbols.",
                        "Never reuse the same password across multiple accounts.",
                        "Consider using a password manager like Bitwarden or LastPass."
                    }},
                { "phishing", new[]
                    {
                        "Phishing is when attackers trick you into giving sensitive information. Always check the URL!",
                        "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organisations.",
                        "Hover over links before clicking them."
                    }},
                { "scam", new[]
                    {
                        "Scams often create urgency or fear. Take time to verify before acting.",
                        "Never send money or personal details to unsolicited requests."
                    }},
                { "privacy", new[]
                    {
                        "Protect your privacy by reviewing app permissions regularly.",
                        "Enable two-factor authentication (2FA) wherever possible."
                    }},
                { "2fa", new[] { "2FA adds an extra layer of security. Use authenticator apps instead of SMS when possible." }},

                { "malware", new[]
                    {
                        "Malware is malicious software designed to harm your device. Keep your antivirus updated.",
                        "Avoid downloading files from untrusted sources to prevent malware infections."
                    }},
                { "ransomware", new[]
                    {
                        "Ransomware locks your files and demands payment. Regular backups are your best defense.",
                        "Never pay the ransom — it encourages more attacks."
                    }},
                { "firewall", new[]
                    {
                        "A firewall acts as a barrier between your network and threats. Make sure it's enabled.",
                        "Use both Windows Firewall and your router's firewall for better protection."
                    }},
                { "vpn", new[]
                    {
                        "A VPN encrypts your internet connection, protecting you on public Wi-Fi.",
                        "Always use a reputable VPN when accessing sensitive information on public networks."
                    }},
                { "antivirus", new[]
                    {
                        "Good antivirus software is essential. Keep it updated and run regular scans.",
                        "Recommended options include Windows Defender, Bitdefender, and Malwarebytes."
                    }},

                // General greetings - FIXED
                { "hello", new[] { "Hello! Great to see you. How can I help with your online safety today?" }},
                { "hi", new[] { "Hello! Great to see you. How can I help with your online safety today?" }},
                { "hey", new[] { "Hello! Great to see you. How can I help with your online safety today?" }},
                { "how are you", new[] { "I'm doing great and ready to help you stay safe online! 🛡️" }}
            };
        }

        public void SetUserName(string name)
        {
            userName = string.IsNullOrWhiteSpace(name) ? "Friend" : name.Trim();
        }

        public void SetFavoriteTopic(string topic)
        {
            favoriteTopic = topic.ToLower();
        }

        public string GetResponse(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return "I didn't catch that. Could you please rephrase?";

            string lowerInput = input.ToLower();

            // Memory & Personalization
            if (lowerInput.Contains("my name is") || lowerInput.Contains("call me"))
            {
                var parts = input.Split(' ');
                var name = parts.Length > 3 ? parts[parts.Length - 1] : "Friend";
                SetUserName(name);
                return $"Nice to meet you, {userName}! I'll remember that.";
            }

            if (lowerInput.Contains("favorite") || lowerInput.Contains("interested in"))
            {
                if (lowerInput.Contains("password")) favoriteTopic = "password";
                else if (lowerInput.Contains("phishing") || lowerInput.Contains("scam")) favoriteTopic = "phishing";
                else if (lowerInput.Contains("privacy")) favoriteTopic = "privacy";
                else if (lowerInput.Contains("malware") || lowerInput.Contains("virus")) favoriteTopic = "malware";

                return $"Great! I'll remember you're interested in {favoriteTopic}.";
            }

            // Sentiment Detection
            if (lowerInput.Contains("worried") || lowerInput.Contains("scared") || lowerInput.Contains("nervous"))
                return $"I understand you're worried, {userName}. Let's take it step by step.";

            if (lowerInput.Contains("confused") || lowerInput.Contains("don't understand"))
                return "No problem! Let me explain it more simply.";

            // Follow-up conversation flow
            if (lowerInput.Contains("another") || lowerInput.Contains("more") || lowerInput.Contains("again") || lowerInput.Contains("tell me more"))
            {
                if (!string.IsNullOrEmpty(favoriteTopic) && responses.ContainsKey(favoriteTopic))
                {
                    return responses[favoriteTopic][rand.Next(responses[favoriteTopic].Length)];
                }
            }

            // Keyword matching - IMPROVED
            foreach (var item in responses)
            {
                if (lowerInput.Contains(item.Key))
                {
                    return item.Value[rand.Next(item.Value.Length)];
                }
            }

            // Fallback
            return "I'm not sure I understood that. Could you try rephrasing? Try asking about passwords, phishing, malware, ransomware, or VPNs.";
        }
    }
}